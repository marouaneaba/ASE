#ifndef _mi_syscall_h
#define _mi_syscall_h

#define SYSCALL_SWTCH_0 16
#define SYSCALL_SWTCH_1 17

#endif
