#ifndef _mi_kernel_h
#define _mi_kernel_h

void mmu_handler();

#endif
