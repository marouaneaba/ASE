#ifndef _mi_user_h
#define _mi_user_h

#define N 127

void init();

#endif
